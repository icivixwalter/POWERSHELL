package com.giacomolorenzo.rossi;

import org.apache.commons.io.FilenameUtils;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Calendar;
import java.util.Date;

public class ComprimiFile {

    //dichiarazione dei campi della classe necessari per mantere lo stato valorizzato in ram
    private int annoInizio_i;
    private int annoFine_i;
    private String pathSorgente_s;
    private String pathDestinazione_s;

    //4 PARAMETRI DEL COSTRUTTORE
    public ComprimiFile(int annoInizio_i, int annoFine_i, String pathSorgente_s, String pathDestinazione_s) {
        //inizializzare i parametri
        this.annoInizio_i = annoInizio_i;
        this.annoFine_i = annoFine_i;
        this.pathSorgente_s = pathSorgente_s;
        this.pathDestinazione_s = pathDestinazione_s;
    }

    public boolean esegui() throws IOException {
        int anno_i;
        int mese_i;
        Calendar instance = Calendar.getInstance();
        for (anno_i = annoInizio_i; anno_i <= annoFine_i; anno_i++) {
            File directoryInput = new File(pathSorgente_s);
            for (mese_i = 1; mese_i <= 12; mese_i++) {

                File[] myfiles = directoryInput.listFiles();
                for (File file : myfiles) {
                    Path filePath = Paths.get(file.getPath());
                    BasicFileAttributes attributi = Files.readAttributes(filePath, BasicFileAttributes.class);
                    Date d = new Date(attributi.lastModifiedTime().toMillis());
                    instance.setTime(d);
                    int mese = 1 + instance.get(Calendar.MONTH);
                    int anno = instance.get(Calendar.YEAR);
                    String nomeFileAnnoMese = String.format("%d-%02d", anno, mese);

                    String estensione = FilenameUtils.getExtension(file.getPath());
                    if (mese == mese_i && anno_i == anno && estensione.equals("pdf")) {
                        System.out.println("nomeFileAnnoMese = " + nomeFileAnnoMese);
                        System.out.println("file.getPath() = " + file.getPath());
                        String dest = pathDestinazione_s + "\\"+nomeFileAnnoMese;
                        System.out.println("dest = " + dest);

                        if(comprimi7z(dest, file.getPath())){
                            System.out.println("Tutto ok con 7zip");
                        } else if (comprimiRar(dest, file.getPath())){
                            System.out.println("Tutto ok con rar");
                        } else{
                            System.out.println("Impossibile trovare rar o 7zip");
                            return false;
                        }
                    }

                }
            }
        }
        return true;
    }

    private boolean comprimi7z(String nomeFileCompresso, String nomeFileDaArchiviare) {
        String lineOutput;
        try {
            // Execute command
            Runtime rt = Runtime.getRuntime();
            String[] commands = {"7z", "a", nomeFileCompresso, nomeFileDaArchiviare};
            Process proc = rt.exec(commands);

            BufferedReader stdError = new BufferedReader(new InputStreamReader(proc.getErrorStream()));

            // Read any errors from the attempted command
            while ((lineOutput = stdError.readLine()) != null) {
                System.out.println(lineOutput);
            }
        } catch (IOException io) {
            io.printStackTrace();
            return false;
        }
        return true;
    }

    private boolean comprimiRar(String nomeFileCompresso, String nomeFileDaArchiviare) {
        String lineOutput;
        try {
            // Execute command
            Runtime rt = Runtime.getRuntime();
            String[] commands = {"c:\\CASA\\Rar.exe", "U", "-r", "-ac", nomeFileCompresso, nomeFileDaArchiviare};
            Process proc = rt.exec(commands);

            BufferedReader stdError = new BufferedReader(new InputStreamReader(proc.getErrorStream()));

            // Read any errors from the attempted command
            while ((lineOutput = stdError.readLine()) != null) {
                System.out.println(lineOutput);
            }
        } catch (IOException io) {
            io.printStackTrace();
            return false;
        }
        return true;
    }
}
