package com.giacomolorenzo.rossi;

import java.io.IOException;
import java.util.Calendar;

public class Main {
    //crea un metodo per inizializzare il programma - punto di partenza
    public static void main(String[] args) {
        System.out.println("inizializzo il programma - main");

        //istanzia la classe (alt+invio crea una classe da solo)
        int annoInizio_i = 2000;
        int annoFine_i = Calendar.getInstance().get(Calendar.YEAR);

        String pathSorgente_s; //"C:\\Users\\giaco\\Desktop\\Prova";
        String pathDestinazione_s; //"C:\\Users\\giaco\\Desktop\\Prova";

        // obbligatori
        try {
            pathSorgente_s = args[0];
            pathDestinazione_s = args[1];
        } catch(IndexOutOfBoundsException i){
            System.out.println("Argomenti non inseriti: path_input path_sorgente");
            return;
        }

        // opzionale
        try{
            annoInizio_i = Integer.parseInt(args[2]);
        } catch(IndexOutOfBoundsException | NumberFormatException i){
            System.out.println("anno di inizio 2000");
        }

        // opzionale
        try {
            annoFine_i = Integer.parseInt(args[3]);
        } catch(IndexOutOfBoundsException | NumberFormatException n){
            System.out.println("anno di inizio: "+ annoFine_i);
        }

        if(annoInizio_i > annoFine_i){
            System.out.println("L'anno di inizio deve essere minore o uguale dell'anno di fine");
            return;
        }

        ComprimiFile mycomprimiFile = new ComprimiFile(annoInizio_i, annoFine_i, pathSorgente_s, pathDestinazione_s);
        try {
            boolean risultato = mycomprimiFile.esegui();
            if(!risultato){
                System.out.println("Errore!!!");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
