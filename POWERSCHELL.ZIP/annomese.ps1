# per ogni file nella cartella, estrae il anno/meseFile di creazione, e archivia tutti 
# i file con lo stesso meseFile in un file compresso che si deve chiamare anno_meseFile.zip

# hardcoded  !!! ----> metti gli anni di inizio e fine
$ANNO_INIZIO = 2000
$ANNO_FINE = 2021


if ($args.Count -eq 0) {
    Write-Output "Errore, specificare la cartella di input"
    exit
}

$startDir=Get-Location

if($args.Count -eq 2){
    $outputDir=$args.get(1) # output = directory a scelta con secondo parametro
} else {
    $outputDir=$args.get(0) # output = come la directory di input
}


Set-Location $args.get(0) # path di input

# $salvataggioFolder = "C:\Users\giaco\Desktop\Prova2\"
for ($anno_i = $ANNO_INIZIO; $anno_i -le $ANNO_FINE; $anno_i++) {
    for ($mese_i = 1; $mese_i -le 12; $mese_i++) {
        foreach ($file in Get-ChildItem $args.Get(0)) {
            # 0 davanti, 4 cifre
            $anno = "{0:d4}" -f $file.LastWriteTime.year
            $meseFile = "{0:d2}" -f $file.LastWriteTime.month
        
            # $nomeFile = "$salvataggioFolder${file.name}"
            $nomeFile = $file.name
        
            # Write-Output $nomeFileCompresso
        
            $meseCorrente = "{0:d2}" -f $mese_i
            $nomeFileCompresso = "$outputDir\${anno_i}_${meseCorrente}"
            $estensione = [IO.Path]::GetExtension($file);
            if ($meseFile -eq $meseCorrente -And $anno_i -eq $anno -And $estensione -eq ".pdf") {
                # aggiunge all'archivio compresso di nome $nomeFileCompresso solo i file del mese pari all'indice
                Write-Output "Comprimo il file ${nomeFile} nell'archivio ${nomeFileCompresso}"
                
                #old zip su giacomo che utilizza 7.zip
                #7z a $nomeFileCompresso $nomeFile
                
                #nuovo utilizzo di rar.exe walter
                c:\CASA\Rar.exe U -r -ac $nomeFileCompresso $nomeFile
            }
        }
    }
}


Set-Location $startDir